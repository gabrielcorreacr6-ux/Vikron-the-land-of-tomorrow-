# Prompts para o Gemini (imagens de referência do Vikron)

Dica: gere, escolha as melhores e me envie aqui. Eu uso como textura/referência no jogo (rosto, símbolos dos clãs, roupas).

## 1. Personagem base (careca, ponto de partida)
Character turnaround sheet (front, side, back), young anime ninja inspired by Naruto, completely bald, neutral gray-beige skin, plain light-gray long-sleeve jacket with no logo, dark pants, simple sandals, standing in A-pose, flat colors with clean black outlines, neutral light background, full body, same proportions in all three views, no text.

## 2. Rosto (textura)
Close-up anime face sheet, front view, bald head, Naruto-style eyes with large iris and white highlight, thick determined eyebrows, small nose, small mouth, flat cel shading, plain skin tone, no hair, no background, 4 variations of eye color (brown, blue, green, red).

## 3. Símbolos dos 7 clãs (um por imagem, fundo transparente se possível)
Round ninja-village emblem, bold simple vector style, thick outline, centered, symmetrical, no text:
- Fire: stylized flame, orange and gold
- Nature: leaf and tree, green
- Water: water drop with waves, blue
- Thunder: lightning bolt, yellow and white
- Wind: swirling air spiral, pale teal
- Earth: mountain with rock, brown and gold
- Aura: glowing crystal star, purple and white

## 4. Faixa de testa (headband)
Ninja forehead protector, metal plate with clan emblem (use the emblem above), cloth band in the clan color, front view, flat anime style, plain background.

## 5. Vilas (textura de chão e casa por clã)
Seamless tileable ground texture, stylized painted look, [fire: volcanic dark rock with glowing cracks / nature: lush grass with flowers / water: wet blue-green stones and shallow water / thunder: dark grassy storm ground with yellow sparks / wind: pale dry meadow with white petals / earth: sandy canyon dirt and pebbles / aura: purple-tinted grass with faint glowing dust], top-down, 1024x1024.

## 6. Lorde Vilkron e dragões (conceito)
Concept art, dark armored giant lord holding a huge glowing red-edged sword, gold horns, tattered red cape, dramatic pose, anime fantasy style, full body.
Dragon concept art, one per element (fire, nature, water, thunder, wind, earth), wings open, stylized, clear silhouette, front 3/4 view.
