# Vikron: The Land of Tomorrow

RPG 3D para navegador (Three.js r128), otimizado para celular.

## Arquivos (todos na raiz do repositório)
- `index.html` – o jogo inteiro
- `agua.jpg` – skin do oceano
- `grama.jpg` – skin do terreno
- `areia.jpg` – skin da praia

Os nomes são sensíveis a maiúsculas/minúsculas no GitHub Pages.

## Texturas (todas na raiz, nomes em minúsculas)
agua, grama, areia, pedra, castelo, madeira, casca, terminal, telhado_azul, telhado_vermelho,
min_ferro, min_ouro, min_carvao, min_cobre, min_diamante (.jpg)

## Como jogar
Joystick à esquerda para andar, botão amarelo para coletar. No PC: WASD/setas e E/espaço.
Cair na água = afogamento.
Lord Vilkron: oferenda semanal de 5.000 moedas na Loja; se falhar, ele desperta e reseta o progresso. Botão de teste na Loja.
Texturas já vão embutidas no index.html (funciona só com ele).
Terreno: modo 🕳️ Cavar abre buracos na grama (precisa de picareta); Terra aterra. Construções originais são indestrutíveis.
Petróleo: precisa de Tambor (loja). Atacar o petróleo com arma/magia faz explodir.

## 🏬 Shopping Vikron (zona segura)
Fica na ilha central, ao sul do castelo. Dentro dele não há combate, dano, explosão, escavação nem construção.
Lojas (chegue perto e toque em 🏪 Loja): Armazém (vender recursos, barril vazio e cheio), Coletes (-30% / -50% de dano), Texturas (cores para suas construções), Clãs (criar clã por 1000 moedas), Feira dos Jogadores (comércio entre jogadores — precisa do servidor) e Balcão (oferenda, classe, nome).

## 🌐 Servidor (Supabase) — opcional
Sem configurar nada, o jogo funciona offline. Para ligar o servidor:
1. Crie um projeto em supabase.com.
2. Authentication > Sign In / Providers: ative "Allow anonymous sign-ins".
3. SQL Editor: cole o conteúdo de `supabase.sql` e clique em Run.
4. Project Settings > API: copie a Project URL e a anon key.
5. No `index.html`, procure `const SUPA_URL = '', SUPA_KEY = '';` e preencha com os dois valores.
Já funciona com servidor: nome e ID únicos no mundo todo, doação por ID (800 por dia), oferenda semanal compartilhada.
Ainda local (próximas etapas): saldo de moedas, cargos com chat colorido, banimento, Feira, PvP.

## 👤 Contas (e-mail e senha) — rode também `supabase_v2.sql`
- Cadastro com e-mail, senha, nome, idade e classe; recuperação de senha por e-mail; progresso salvo na nuvem (vale em qualquer aparelho).
- A idade só é visível ao administrador (Balcão > Consultar jogador; e a confirmação aparece antes de cada doação do admin).
- No Supabase: Authentication > URL Configuration: coloque o endereço do seu GitHub Pages em Site URL e em Redirect URLs.
- Para virar admin: `update players set role = 'admin' where lower(name) = lower('SEU_NOME');`

## 🛏️ Casa e nascimento
Modo Construir > bloco "Cama" (6 madeira) define sua casa. Você renasce nela; se a cama for destruída, renasce em lugar aleatório. Ao entrar no jogo também nasce em lugar aleatório (ou em casa).

## 🚂 Trens
3 trens a vapor (locomotiva, tensor e 7 vagões) circulam pela ferrovia, soltando fumaça. Cada um para 6 segundos nas estações, e as estações são salões por onde o trem passa por dentro.

## 🎫 Bilheteria e 2ª ferrovia
Cada estação tem bilheteria, quadro de preços, fila de embarque (círculo amarelo) e desembarque (círculo verde); as estações são zona segura. Compre o bilhete, vá à fila e, quando o trem parar na estação, você é levado ao desembarque do destino. Preço por distância (perto, médio, longe), definido pelo admin no Balcão; com servidor, rode também `supabase_v3.sql`.
Há duas ferrovias lado a lado, em sentidos opostos, com 3 trens cada.

## ⛏️ Subsolo (camadas) e 🔦 tochas
Modo Cavar: cave um buraco (camada 1) e cave de novo no mesmo buraco para descer (camadas 2 e 3). Dentro de um buraco, cavar ao lado abre um túnel na mesma camada. Camada 1: terra, pedra, carvão. Camada 2: pedra, carvão, ferro, cobre, ouro raro (pede picareta de ferro). Camada 3 (pede picareta de ferro): ferro, ouro, diamante (picareta de ouro), petróleo (precisa de Tambor). Nas camadas 2 e 3 fica escuro; tochas (1 madeira + 1 carvão = 2) iluminam por 90 s cada. Terra aterra uma camada por vez.

## 🧍 Personagem
Skin básica com rosto, cabelo, camisa na cor da classe, cinto, calça e botas; pernas e braços se mexem ao andar.

## 🛠️ Admin (testes)
Conta com role admin vê o botão 🛠️ Admin: moedas e recursos, ferramentas de diamante, imortal, teleporte (castelo, shopping, estações), chamar trem, preço dos bilhetes e despertar o Lord Vilkron.

## 🎮 Controles estilo Minecraft
Barra de itens embaixo (6 slots + ••• para o inventário). Toque num slot para escolher ferramenta ou bloco; o botão amarelo faz a ação certa (cavar, cortar, demolir, colocar, atacar). Segure para repetir. Em ⚙️ dá para trocar analógico ↔ direcional e a distância da câmera (Perto = padrão). Cavar vai até 6 camadas (4 de altura cada); escuridão a partir da camada 3.

## ☠️ Lord Vilkron e 🐉 dragões — rode `supabase_v4.sql`
- Lord Vilkron dorme na ilha noroeste. Ao despertar (meta da oferenda falhou, ou admin), todos veem ele andar da ilha dele até a Ilha Central, destruindo construções; ao chegar, o estouro reseta o jogo. O relógio é do servidor (igual para todos).
- Outras 6 ilhas têm uma caverna com um dragão dormindo e um baú. Dragão: acorda se atacado, perturbado ou se o baú for pego; voa, cospe fogo e persegue quem está com pouca vida. Morreu: volta em 5 min. Baú pego: volta em 7 min.
- Recompensa do baú: itens definidos pelo admin ou o total da oferenda da semana (não reduz a oferenda). Configure em 🛠️ Admin → Baús.

## Atualização 21 — Mundo pronto
- Sem cavar/construir: recursos só na superfície (árvores, pedras, minérios, trigo regeneram).
- Toque direto no alvo para coletar/atacar (botão COLETAR removido).
- ~150 casas prontas (favela, pequena, média, grande, luxo) em todas as ilhas, longe da ferrovia. Trancadas: compre ou alugue na Imobiliária (loja "casas"). Rode `supabase_v5.sql` (depois do v4).
- Ciclo dia/noite (20 min, igual para todos) e bioma próprio por ilha.
- Admin: botões Meio-dia / Meia-noite / Pôr do sol e "Todas as portas ABERTAS".
- Pendente: Feira (jogadores negociam casas/espadas/cetros/arcos).

## Atualização 22 — Clãs de elemento
- Sem ferramentas/armas: todos socam. 3 botões: 1 = tiro elemental (liga/desliga), 2 = escudo (segure; gasta energia), 3 = fúria (punhos com o elemento). Barra azul = energia.
- 7 clãs na criação: Fire, Nature, Water, Thunder, Wind, Earth, Aura. Cada ilha é a vila de um clã (centro = Aura) com monumento próprio. Vilkron fica nas Terras Sombrias.
- Personagem, Lorde Vilkron e dragões redesenhados (dragões com a cor/fogo do elemento da ilha).
- Postes de luz na frente de cada casa e luz interna à noite.
- Rode `supabase_v6.sql` (depois do v5).

## Atualização 23
- Só moedas no topo (engrenagem ao lado). Recursos viram moedas ao coletar (e às vezes dropam itens). Recursos antigos foram convertidos em moedas.
- Itens: cura, cura em área, invisibilidade, voo, granada paralisante (Armazém e Arsenal, no Shopping). Barra de itens à esquerda.
- 4º botão: pulo (1 toque) e dash (2 toques).
- Modo tiro: tocar na tela atira naquela direção, sem andar.
- Personagem humanizado; criador (pele, cabelo, barba, olhos, camisa) abre na 1ª entrada; símbolo do clã nas costas. Prompts do Gemini em PROMPTS_GEMINI.md.
- Pendente (precisa de multiplayer): nomes só de perto, melhores amigos (até 6), efeitos em jogadores rivais/aliados.
