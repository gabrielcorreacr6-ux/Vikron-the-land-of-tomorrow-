# Vikron: The Land of Tomorrow

RPG 3D para navegador (Three.js r128), otimizado para celular.

## Arquivos (todos na raiz do repositório)
- `index.html` – o jogo inteiro
- `agua.jpg` – skin do oceano
- `grama.jpg` – skin do terreno
- `areia.jpg` – skin da praia

Os nomes são sensíveis a maiúsculas/minúsculas no GitHub Pages.

## Texturas (todas na raiz, nomes em minúsculas)
agua, grama, areia, pedra, castelo, madeira, casca, terminal, telhado_azul, telhado_vermelho,
min_ferro, min_ouro, min_carvao, min_cobre, min_diamante (.jpg)

## Como jogar
Joystick à esquerda para andar, botão amarelo para coletar. No PC: WASD/setas e E/espaço.
Cair na água = afogamento.
Lord Vilkron: oferenda semanal de 5.000 moedas na Loja; se falhar, ele desperta e reseta o progresso. Botão de teste na Loja.
Texturas já vão embutidas no index.html (funciona só com ele).
Terreno: modo 🕳️ Cavar abre buracos na grama (precisa de picareta); Terra aterra. Construções originais são indestrutíveis.
Petróleo: precisa de Tambor (loja). Atacar o petróleo com arma/magia faz explodir.

## 🏬 Shopping Vikron (zona segura)
Fica na ilha central, ao sul do castelo. Dentro dele não há combate, dano, explosão, escavação nem construção.
Lojas (chegue perto e toque em 🏪 Loja): Armazém (vender recursos, barril vazio e cheio), Coletes (-30% / -50% de dano), Texturas (cores para suas construções), Clãs (criar clã por 1000 moedas), Feira dos Jogadores (comércio entre jogadores — precisa do servidor) e Balcão (oferenda, classe, nome).

## 🌐 Servidor (Supabase) — opcional
Sem configurar nada, o jogo funciona offline. Para ligar o servidor:
1. Crie um projeto em supabase.com.
2. Authentication > Sign In / Providers: ative "Allow anonymous sign-ins".
3. SQL Editor: cole o conteúdo de `supabase.sql` e clique em Run.
4. Project Settings > API: copie a Project URL e a anon key.
5. No `index.html`, procure `const SUPA_URL = '', SUPA_KEY = '';` e preencha com os dois valores.
Já funciona com servidor: nome e ID únicos no mundo todo, doação por ID (800 por dia), oferenda semanal compartilhada.
Ainda local (próximas etapas): saldo de moedas, cargos com chat colorido, banimento, Feira, PvP.

## 👤 Contas (e-mail e senha) — rode também `supabase_v2.sql`
- Cadastro com e-mail, senha, nome, idade e classe; recuperação de senha por e-mail; progresso salvo na nuvem (vale em qualquer aparelho).
- A idade só é visível ao administrador (Balcão > Consultar jogador; e a confirmação aparece antes de cada doação do admin).
- No Supabase: Authentication > URL Configuration: coloque o endereço do seu GitHub Pages em Site URL e em Redirect URLs.
- Para virar admin: `update players set role = 'admin' where lower(name) = lower('SEU_NOME');`

## 🛏️ Casa e nascimento
Modo Construir > bloco "Cama" (6 madeira) define sua casa. Você renasce nela; se a cama for destruída, renasce em lugar aleatório. Ao entrar no jogo também nasce em lugar aleatório (ou em casa).

## 🚂 Trens
3 trens a vapor (locomotiva, tensor e 7 vagões) circulam pela ferrovia, soltando fumaça. Cada um para 6 segundos nas estações, e as estações são salões por onde o trem passa por dentro.
