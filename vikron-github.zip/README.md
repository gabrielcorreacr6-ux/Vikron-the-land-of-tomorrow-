# Vikron: The Land of Tomorrow

RPG 3D para navegador (Three.js r128), otimizado para celular.

## Arquivos (todos na raiz do repositório)
- `index.html` – o jogo inteiro
- `agua.jpg` – skin do oceano
- `grama.jpg` – skin do terreno
- `areia.jpg` – skin da praia

Os nomes são sensíveis a maiúsculas/minúsculas no GitHub Pages.

## Texturas (todas na raiz, nomes em minúsculas)
agua, grama, areia, pedra, castelo, madeira, casca, terminal, telhado_azul, telhado_vermelho,
min_ferro, min_ouro, min_carvao, min_cobre, min_diamante (.jpg)

## Como jogar
Joystick à esquerda para andar, botão amarelo para coletar. No PC: WASD/setas e E/espaço.
Cair na água = afogamento.
Petróleo: precisa de Tambor (loja). Atacar o petróleo com arma/magia faz explodir.
