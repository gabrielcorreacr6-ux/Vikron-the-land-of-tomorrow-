-- VIKRON · servidor (Supabase) · cole tudo no SQL Editor e clique em Run
-- Antes: Authentication > Sign In / Providers > ative "Allow anonymous sign-ins"

create table if not exists settings (
  id int primary key default 1 check (id = 1),
  epoch timestamptz not null default now(),   -- início da semana 0 da oferenda
  goal int not null default 5000,
  daily_limit int not null default 800
);
insert into settings default values on conflict do nothing;

create table if not exists players (
  uid text primary key,
  auth_id uuid unique not null,
  name text not null,
  cls text not null default 'guerreiro',
  role text not null default 'user' check (role in ('user','worker','mod','admin')),
  banned boolean not null default false,
  created_at timestamptz not null default now()
);
create unique index if not exists players_name_lower on players (lower(name));

create table if not exists transfers (
  id bigserial primary key,
  from_uid text not null,
  to_uid text not null,
  amount int not null check (amount > 0),
  claimed boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists transfers_to on transfers (to_uid) where not claimed;
create index if not exists transfers_from on transfers (from_uid, created_at);

create table if not exists offerings (
  id bigserial primary key,
  week int not null,
  uid text not null,
  amount int not null check (amount > 0),
  created_at timestamptz not null default now()
);

-- ninguém acessa as tabelas direto: tudo passa pelas funções abaixo
alter table settings enable row level security;
alter table players enable row level security;
alter table transfers enable row level security;
alter table offerings enable row level security;

create or replace function register_player(p_name text, p_cls text)
returns text language plpgsql security definer set search_path = public as $$
declare v players; n int := 0; new_uid text;
begin
  if auth.uid() is null then raise exception 'no_auth'; end if;
  p_name := trim(p_name);
  if p_name !~ '^[A-Za-z0-9_]{3,16}$' then raise exception 'bad_name'; end if;
  if lower(p_name) in ('admin','vikron','moderador','gm','sistema') then raise exception 'name_taken'; end if;
  if p_cls not in ('guerreiro','arqueiro','mago','sacerdote','artesao') then p_cls := 'guerreiro'; end if;
  select * into v from players where auth_id = auth.uid();
  if found then
    if v.banned then raise exception 'banned'; end if;
    begin
      update players set name = p_name, cls = p_cls where auth_id = auth.uid();
    exception when unique_violation then raise exception 'name_taken';
    end;
    return v.uid;
  end if;
  loop
    n := n + 1;
    new_uid := 'VK-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
    begin
      insert into players (uid, auth_id, name, cls) values (new_uid, auth.uid(), p_name, p_cls);
      return new_uid;
    exception when unique_violation then
      if exists (select 1 from players where lower(name) = lower(p_name)) then raise exception 'name_taken'; end if;
      if n > 5 then raise exception 'try_again'; end if;
    end;
  end loop;
end $$;

create or replace function set_class(p_cls text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_cls not in ('guerreiro','arqueiro','mago','sacerdote','artesao') then raise exception 'bad_class'; end if;
  update players set cls = p_cls where auth_id = auth.uid() and not banned;
end $$;

-- doação por ID: limite diário (24h) para todos, exceto admin
create or replace function donate_to(p_uid text, p_amount int)
returns int language plpgsql security definer set search_path = public as $$
declare me players; tg players; s settings; used int; lim int;
begin
  select * into me from players where auth_id = auth.uid();
  if not found then raise exception 'no_player'; end if;
  if me.banned then raise exception 'banned'; end if;
  if p_amount is null or p_amount <= 0 or p_amount > 1000000 then raise exception 'bad_amount'; end if;
  select * into tg from players where uid = upper(trim(p_uid));
  if not found then raise exception 'no_target'; end if;
  if tg.uid = me.uid then raise exception 'self'; end if;
  select * into s from settings where id = 1;
  if me.role = 'admin' then
    insert into transfers (from_uid, to_uid, amount) values (me.uid, tg.uid, p_amount);
    return -1;
  end if;
  select coalesce(sum(amount), 0) into used from transfers where from_uid = me.uid and created_at > now() - interval '24 hours';
  lim := s.daily_limit - used;
  if p_amount > lim then raise exception 'limit:%', greatest(lim, 0); end if;
  insert into transfers (from_uid, to_uid, amount) values (me.uid, tg.uid, p_amount);
  return lim - p_amount;
end $$;

create or replace function claim_transfers()
returns int language plpgsql security definer set search_path = public as $$
declare me players; total int;
begin
  select * into me from players where auth_id = auth.uid();
  if not found then return 0; end if;
  with c as (update transfers set claimed = true where to_uid = me.uid and not claimed returning amount)
  select coalesce(sum(amount), 0) into total from c;
  return total;
end $$;

create or replace function offer_state()
returns json language plpgsql security definer set search_path = public as $$
declare s settings; w int; secs numeric; paid int; prev int;
begin
  select * into s from settings where id = 1;
  secs := extract(epoch from now() - s.epoch);
  w := floor(secs / 604800);
  select coalesce(sum(amount), 0) into paid from offerings where week = w;
  if w > 0 then select coalesce(sum(amount), 0) into prev from offerings where week = w - 1; end if;
  return json_build_object('week', w, 'paid', paid, 'prev_paid', prev,
    'ms_left', floor(((w + 1) * 604800 - secs) * 1000)::bigint, 'goal', s.goal);
end $$;

create or replace function offer_add(p_amount int)
returns json language plpgsql security definer set search_path = public as $$
declare me players; w int;
begin
  select * into me from players where auth_id = auth.uid();
  if not found then raise exception 'no_player'; end if;
  if me.banned then raise exception 'banned'; end if;
  if p_amount is null or p_amount <= 0 or p_amount > 1000000 then raise exception 'bad_amount'; end if;
  w := (offer_state()->>'week')::int;
  insert into offerings (week, uid, amount) values (w, me.uid, p_amount);
  return offer_state();
end $$;

revoke all on function register_player(text,text), set_class(text), donate_to(text,int), claim_transfers(), offer_state(), offer_add(int) from public, anon;
grant execute on function register_player(text,text), set_class(text), donate_to(text,int), claim_transfers(), offer_state(), offer_add(int) to authenticated;

-- Para se tornar admin depois de entrar no jogo (troque SEU_NOME):
-- update players set role = 'admin' where lower(name) = lower('SEU_NOME');
