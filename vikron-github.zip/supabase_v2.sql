-- VIKRON · servidor v2 (contas com e-mail e senha, idade, save na nuvem)
-- Rode DEPOIS do supabase.sql. Pode rodar mais de uma vez.
-- Antes: Authentication > Sign In / Providers: "Email" ligado. Pode desligar o login anônimo.

-- Apaga jogadores de teste da versão anterior (sem conta/idade), para liberar os nomes
alter table players add column if not exists age int check (age between 5 and 120);
alter table players add column if not exists save jsonb;
alter table players add column if not exists save_at timestamptz;
delete from players where age is null;

drop function if exists register_player(text, text);

create or replace function register_player(p_name text, p_cls text, p_age int)
returns text language plpgsql security definer set search_path = public as $$
declare n int := 0; new_uid text;
begin
  if auth.uid() is null or coalesce((auth.jwt() ->> 'is_anonymous')::boolean, false) then raise exception 'need_account'; end if;
  if exists (select 1 from players where auth_id = auth.uid()) then raise exception 'already'; end if;
  p_name := trim(p_name);
  if p_name !~ '^[A-Za-z0-9_]{3,16}$' then raise exception 'bad_name'; end if;
  if lower(p_name) in ('admin','vikron','moderador','gm','sistema') then raise exception 'name_taken'; end if;
  if p_age is null or p_age < 5 or p_age > 120 then raise exception 'bad_age'; end if;
  if p_cls not in ('guerreiro','arqueiro','mago','sacerdote','artesao') then p_cls := 'guerreiro'; end if;
  loop
    n := n + 1;
    new_uid := 'VK-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
    begin
      insert into players (uid, auth_id, name, cls, age) values (new_uid, auth.uid(), p_name, p_cls, p_age);
      return new_uid;
    exception when unique_violation then
      if exists (select 1 from players where lower(name) = lower(p_name)) then raise exception 'name_taken'; end if;
      if exists (select 1 from players where auth_id = auth.uid()) then raise exception 'already'; end if;
      if n > 5 then raise exception 'try_again'; end if;
    end;
  end loop;
end $$;

create or replace function my_player()
returns json language sql security definer set search_path = public stable as $$
  select json_build_object('uid', uid, 'name', name, 'cls', cls, 'role', role, 'banned', banned)
  from players where auth_id = auth.uid()
$$;

create or replace function name_free(p_name text)
returns boolean language sql security definer set search_path = public stable as $$
  select lower(trim(p_name)) not in ('admin','vikron','moderador','gm','sistema')
     and not exists (select 1 from players where lower(name) = lower(trim(p_name)))
$$;

create or replace function rename_player(p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  p_name := trim(p_name);
  if p_name !~ '^[A-Za-z0-9_]{3,16}$' then raise exception 'bad_name'; end if;
  if lower(p_name) in ('admin','vikron','moderador','gm','sistema') then raise exception 'name_taken'; end if;
  begin
    update players set name = p_name where auth_id = auth.uid() and not banned;
  exception when unique_violation then raise exception 'name_taken';
  end;
end $$;

create or replace function cloud_save(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_data is not null and length(p_data::text) > 3000000 then raise exception 'too_big'; end if;
  update players set save = p_data, save_at = now() where auth_id = auth.uid() and not banned;
end $$;

create or replace function cloud_load()
returns jsonb language sql security definer set search_path = public stable as $$
  select save from players where auth_id = auth.uid()
$$;

-- só o administrador vê a idade de um jogador
create or replace function admin_player_info(p_uid text)
returns json language plpgsql security definer set search_path = public stable as $$
declare me players; tg players;
begin
  select * into me from players where auth_id = auth.uid();
  if not found or me.role <> 'admin' then raise exception 'forbidden'; end if;
  select * into tg from players where uid = upper(trim(p_uid));
  if not found then raise exception 'no_target'; end if;
  return json_build_object('uid', tg.uid, 'name', tg.name, 'age', tg.age, 'role', tg.role, 'banned', tg.banned);
end $$;

revoke all on function register_player(text,text,int), my_player(), name_free(text), rename_player(text), cloud_save(jsonb), cloud_load(), admin_player_info(text) from public, anon;
grant execute on function register_player(text,text,int), my_player(), rename_player(text), cloud_save(jsonb), cloud_load(), admin_player_info(text) to authenticated;
grant execute on function name_free(text) to anon, authenticated;
