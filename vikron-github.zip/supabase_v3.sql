-- VIKRON · servidor v3 (preço dos bilhetes de trem, definido pelo administrador)
-- Rode DEPOIS do supabase_v2.sql. Pode rodar mais de uma vez.
alter table settings add column if not exists ticket_prices int[] not null default '{10,25,45}';

create or replace function ticket_prices()
returns int[] language sql security definer set search_path = public stable as $$
  select s.ticket_prices from settings s where s.id = 1
$$;

-- [perto, médio, longe]: sempre crescente
create or replace function set_ticket_prices(p_prices int[])
returns void language plpgsql security definer set search_path = public as $$
declare me players;
begin
  select * into me from players where auth_id = auth.uid();
  if not found or me.role <> 'admin' then raise exception 'forbidden'; end if;
  if array_length(p_prices, 1) <> 3 or p_prices[1] < 1 or p_prices[3] > 100000
     or not (p_prices[1] < p_prices[2] and p_prices[2] < p_prices[3]) then raise exception 'bad_prices'; end if;
  update settings set ticket_prices = p_prices where id = 1;
end $$;

revoke all on function ticket_prices(), set_ticket_prices(int[]) from public, anon;
grant execute on function ticket_prices(), set_ticket_prices(int[]) to authenticated;
