-- VIKRON · servidor v4 (Lord Vilkron compartilhado + baús dos dragões)
-- Rode DEPOIS do supabase_v3.sql. Pode rodar mais de uma vez.
create table if not exists world (
  id int primary key default 1 check (id = 1),
  vk_id bigint not null default 0,                 -- número do último despertar
  vk_at timestamptz,                               -- quando ele despertou (nulo = dormindo)
  vk_week int not null default -1,                 -- semana que já causou um despertar
  chest_mode text not null default 'admin',        -- 'admin' ou 'oferenda'
  chest_items jsonb not null default '{"coins":300,"gold":5}'
);
insert into world default values on conflict do nothing;
alter table world enable row level security;

-- todos os jogadores veem o mesmo Lord Vilkron: o relógio é do servidor
create or replace function vilkron_state()
returns json language sql security definer set search_path = public stable as $$
  select json_build_object('id', w.vk_id,
    'elapsed', case when w.vk_at is null then null else extract(epoch from now() - w.vk_at) end)
  from world w where w.id = 1
$$;

-- p_force = true: só administrador. Sem força: só se a meta da semana anterior falhou (1 vez por semana)
create or replace function vilkron_wake(p_force boolean default false)
returns json language plpgsql security definer set search_path = public as $$
declare me players; o json; w int; wk int;
begin
  select * into me from players where auth_id = auth.uid();
  if not found then raise exception 'no_player'; end if;
  o := offer_state(); w := (o->>'week')::int;
  if p_force then
    if me.role <> 'admin' then raise exception 'forbidden'; end if;
  else
    if w < 1 or coalesce((o->>'prev_paid')::int, 0) >= (o->>'goal')::int then raise exception 'not_due'; end if;
    select vk_week into wk from world where id = 1;
    if wk >= w then raise exception 'already'; end if;
  end if;
  update world set vk_id = vk_id + 1, vk_at = now(), vk_week = case when p_force then vk_week else w end where id = 1;
  return vilkron_state();
end $$;

create or replace function vilkron_cancel()
returns void language plpgsql security definer set search_path = public as $$
declare me players;
begin
  select * into me from players where auth_id = auth.uid();
  if not found or me.role <> 'admin' then raise exception 'forbidden'; end if;
  update world set vk_at = null where id = 1;
end $$;

-- recompensa dos baús: 'admin' = itens definidos aqui; 'oferenda' = total arrecadado na semana (não reduz a oferenda)
create or replace function chest_config()
returns json language sql security definer set search_path = public stable as $$
  select json_build_object('mode', w.chest_mode, 'items', w.chest_items) from world w where w.id = 1
$$;

create or replace function set_chest_config(p_mode text, p_items jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare me players; k text; v numeric;
begin
  select * into me from players where auth_id = auth.uid();
  if not found or me.role <> 'admin' then raise exception 'forbidden'; end if;
  if p_mode not in ('admin', 'oferenda') then raise exception 'bad_mode'; end if;
  for k, v in select key, value::numeric from jsonb_each_text(p_items) loop
    if k not in ('coins','gold','diamond','iron','copper','coal','oil','wood','stone') or v < 0 or v > 1000000 then raise exception 'bad_item'; end if;
  end loop;
  update world set chest_mode = p_mode, chest_items = p_items where id = 1;
end $$;

revoke all on function vilkron_state(), vilkron_wake(boolean), vilkron_cancel(), chest_config(), set_chest_config(text,jsonb) from public, anon;
grant execute on function vilkron_state(), vilkron_wake(boolean), vilkron_cancel(), chest_config(), set_chest_config(text,jsonb) to authenticated;
