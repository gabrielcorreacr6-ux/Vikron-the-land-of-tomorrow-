-- VIKRON · servidor v5 (casas: compra e aluguel)
-- Rode DEPOIS do supabase_v4.sql. Pode rodar mais de uma vez.
create table if not exists houses (
  id int primary key,
  owner text, owner_name text,            -- dono (comprou)
  renter text, renter_name text,          -- inquilino
  until timestamptz                       -- fim do aluguel
);
alter table houses enable row level security;

create or replace function house_state()
returns json language sql security definer set search_path = public stable as $$
  select coalesce(json_agg(json_build_object('id', id, 'owner', owner, 'owner_name', owner_name,
    'renter', case when until > now() then renter end, 'renter_name', case when until > now() then renter_name end,
    'until', case when until is null then 0 else floor(extract(epoch from until) * 1000)::bigint end)), '[]'::json)
  from houses where owner is not null or (renter is not null and until > now())
$$;

create or replace function house_buy(p_id int)
returns void language plpgsql security definer set search_path = public as $$
declare me players; r houses; n int;
begin
  select * into me from players where auth_id = auth.uid();
  if not found then raise exception 'no_player'; end if;
  if p_id < 1 or p_id > 5000 then raise exception 'bad_id'; end if;
  select * into r from houses where id = p_id;
  if found and (r.owner is not null or (r.renter is not null and r.until > now() and r.renter <> me.uid)) then raise exception 'taken'; end if;
  select count(*) into n from houses where owner = me.uid or (renter = me.uid and until > now());
  if n >= 3 and me.role <> 'admin' and not (found and r.renter = me.uid) then raise exception 'limit'; end if;
  insert into houses (id, owner, owner_name) values (p_id, me.uid, me.name)
  on conflict (id) do update set owner = me.uid, owner_name = me.name, renter = null, renter_name = null, until = null;
end $$;

create or replace function house_rent(p_id int)
returns void language plpgsql security definer set search_path = public as $$
declare me players; r houses; n int; base timestamptz;
begin
  select * into me from players where auth_id = auth.uid();
  if not found then raise exception 'no_player'; end if;
  if p_id < 1 or p_id > 5000 then raise exception 'bad_id'; end if;
  select * into r from houses where id = p_id;
  if found and (r.owner is not null or (r.renter is not null and r.until > now() and r.renter <> me.uid)) then raise exception 'taken'; end if;
  if not (found and r.renter = me.uid and r.until > now()) then
    select count(*) into n from houses where owner = me.uid or (renter = me.uid and until > now());
    if n >= 3 and me.role <> 'admin' then raise exception 'limit'; end if;
  end if;
  base := greatest(now(), coalesce(case when found and r.renter = me.uid then r.until end, now()));
  if base > now() + interval '21 days' then raise exception 'max'; end if;
  insert into houses (id, renter, renter_name, until) values (p_id, me.uid, me.name, base + interval '7 days')
  on conflict (id) do update set renter = me.uid, renter_name = me.name, until = base + interval '7 days', owner = null, owner_name = null;
end $$;

create or replace function house_release(p_id int)
returns void language plpgsql security definer set search_path = public as $$
declare me players;
begin
  select * into me from players where auth_id = auth.uid();
  if not found then raise exception 'no_player'; end if;
  update houses set owner = null, owner_name = null, renter = null, renter_name = null, until = null
  where id = p_id and (owner = me.uid or renter = me.uid);
end $$;

revoke all on function house_state(), house_buy(int), house_rent(int), house_release(int) from public, anon;
grant execute on function house_state(), house_buy(int), house_rent(int), house_release(int) to authenticated;
