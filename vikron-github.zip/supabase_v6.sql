-- VIKRON · servidor v6 (clãs = elementos)
-- Rode DEPOIS do v5. Pode rodar mais de uma vez.
-- Clãs: fire, nature, water, thunder, wind, earth, aura

update players set cls = 'fire' where cls not in ('fire','nature','water','thunder','wind','earth','aura');

create or replace function register_player(p_name text, p_cls text, p_age int)
returns text language plpgsql security definer set search_path = public as $$
declare n int := 0; new_uid text;
begin
  if auth.uid() is null or coalesce((auth.jwt() ->> 'is_anonymous')::boolean, false) then raise exception 'need_account'; end if;
  if exists (select 1 from players where auth_id = auth.uid()) then raise exception 'already'; end if;
  p_name := trim(p_name);
  if p_name !~ '^[A-Za-z0-9_]{3,16}$' then raise exception 'bad_name'; end if;
  if lower(p_name) in ('admin','vikron','moderador','gm','sistema') then raise exception 'name_taken'; end if;
  if p_age is null or p_age < 5 or p_age > 120 then raise exception 'bad_age'; end if;
  if p_cls not in ('fire','nature','water','thunder','wind','earth','aura') then p_cls := 'fire'; end if;
  loop
    n := n + 1;
    new_uid := 'VK-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 8));
    begin
      insert into players (uid, auth_id, name, cls, age) values (new_uid, auth.uid(), p_name, p_cls, p_age);
      return new_uid;
    exception when unique_violation then
      if exists (select 1 from players where lower(name) = lower(p_name)) then raise exception 'name_taken'; end if;
      if exists (select 1 from players where auth_id = auth.uid()) then raise exception 'already'; end if;
      if n > 5 then raise exception 'try_again'; end if;
    end;
  end loop;
end $$;

create or replace function set_class(p_cls text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_cls not in ('fire','nature','water','thunder','wind','earth','aura') then raise exception 'bad_class'; end if;
  update players set cls = p_cls where auth_id = auth.uid() and not banned;
end $$;

grant execute on function register_player(text, text, int) to authenticated;
grant execute on function set_class(text) to authenticated;
